import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.io.*;

public class MostFrequentDestMapper extends
    Mapper<LongWritable, Text, KeyPair, Text> {
	Text textKey = new Text();
	Text textValue = new Text();
	
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {
	  int i;
	 String line = value.toString();
	 for (i=0;i<line.length();i++){
		 if (line.charAt(i)==' '){
			 break;
		 }
	 }
	 String mainkey = line.substring(0,i);

	 for (i=0;i<line.length();i++){
		 if (line.charAt(i)=='['){
			 break;
		 }
	 }
	 String accesstime = line.substring(i,i+28);

		//int deptDelay = Integer.parseInt(columns[15]);
		 //int i = 1;
		 //String s = uniqueDestination;
		 //String v= s+","+String.valueOf(i);
		 textValue.set(accesstime);
         //context.write(new Text(uniqueCarrier+" "+uniqueOrigin), textValue);
         context.write(new KeyPair(mainkey, accesstime), textValue);
	 }
    }
 

