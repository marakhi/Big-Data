//package uis.bigdataclass.MaxBirthtyear;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.hadoop.io.*;
/**
 * A comparator for the KeyPair class that compairs by lastname and then birth year Desc
 * This comparator is used for sorting the keypair by the mapreduce framework
 * @author Ellie Buxton
 *
 */
public class NameYearComparator extends WritableComparator {


	public NameYearComparator() {
		super(KeyPair.class, true);	
	}
	
	public int compare(WritableComparable k1, WritableComparable k2)
	{
		KeyPair key1 = (KeyPair) k1;
		KeyPair key2= (KeyPair) k2;
		int c = key1.getmainkey().compareTo(key2.getmainkey());
		if (c ==0){
			SimpleDateFormat format = new SimpleDateFormat("[dd/MMM/YYYY:HH:mm:ss Z]", Locale.US);
			Date date1 = null;
			try {
				//System.out.println(key1.getaccesstime().toString());
				date1 = format.parse(key1.getaccesstime().toString());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Date date2 = null;
			try {
				date2 = format.parse(key2.getaccesstime().toString());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return -date1.compareTo(date2);
			}
		else
			return c;
	}
}
