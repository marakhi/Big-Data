import java.io.IOException;

import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.io.*;

public class MostFrequentDestReducer extends
    Reducer<KeyPair, Text, Text, Text> {
	
	Text textValue = new Text();
  public void reduce(KeyPair key, Iterable<Text> values, Context context)
      throws IOException, InterruptedException {
    int i = 0;
		for (Text value : values) {
			i = i+1;
			String s = value.toString();
			context.write(key.getmainkey(), new Text(value));
			if (i==3){
				i=0;
				break;
			}
			
		}
			

  }
}
