import java.io.IOException;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.io.*;
public class MeanMapper extends
Mapper<LongWritable, Text, Text, MeanPair> {
public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException 
{

	//Extracting the user_id and elapsed time
	  String line = value.toString().replaceAll("\\p{Punct}|\\d", "").toLowerCase();
  //Extracting the words
	 String[]columns = value.toString().split(",");
	 String uniqueCarrier= columns[8];
// 	 String DepDelay= columns[15];
//	if (uniqueCarrier.equals(" ")||uniqueCarrier.equals("NA")||uniqueCarrier.equals("uniqueCarrier")){
//	
//
//	}				 
//	else {
//		
//			//Emitting key=user_id value- pair(elapsed_time, 1)
//		context.write(new Text(uniqueCarrier), new MeanPair(Double.parseDouble(DepDelay),1));
//	};

	 try
	 {
		 double deptDelay = Double.parseDouble(columns[15]);
		 context.write(new Text(uniqueCarrier), new MeanPair(deptDelay,1));
	 }   
	 catch(NumberFormatException e)
	 {
	 }
	 
}
}
