//package solution;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.ArrayList;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.io.*;

public class AsymmetricMapper extends
    Mapper<LongWritable, Text, Text, Text> 
{
   public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException 
   {

  	  String line = value.toString().trim();
      line = line.trim().replaceAll("\n", "");
      
      String[] result = line.split("\t");
      
      String mykeya = result[0].trim();
      // key for relation A [uniquecarrier, yy-mm-dd, origin]
      String mykeyb = result[1].trim();
      
      context.write(new Text(mykeya), new Text("a"+","+result[1].trim()));
      context.write(new Text(mykeyb), new Text("b"+","+result[0].trim()));
    }
  }

