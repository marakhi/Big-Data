import java.io.IOException;
import java.util.*;


import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.io.*;

public class AsymmetricReducer extends
    Reducer<Text, Text, Text, Text> {
  public void reduce(Text key, Iterable<Text> values, Context context)
      throws IOException, InterruptedException {
	  
	 int count = 0;
	 String[] splits = null;
	 ArrayList<String> aPart = new ArrayList<String>();
	 ArrayList<String> bPart = new ArrayList<String>();
	
		for (Text line : values) {
			splits = line.toString().split(",");
			count = count + 1;
		     if(splits[0].toLowerCase().equals("a"))
		     {
		    	 aPart.add(splits[1]);
		    	 
		     }
		     else
		     {
		    	 bPart.add(splits[1]);
		     }
		}
		
    	for(String aline : aPart)
        {	
    		if (bPart.contains(aline)){
    			
    		}else {
    			context.write(new Text(key), new Text(aline));
    		}
        }
  }
}
