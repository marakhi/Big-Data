import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.io.*;

public class CommonFollowersReducer extends
    Reducer<IntWritable, IntWritable, Text, IntWritable> {
	
	//Text textValue = new Text();
  public void reduce(IntWritable key, Iterable<IntWritable> values, Context context)
      throws IOException, InterruptedException {
	  String key1 = null;
	  String prev = " "; 
	  ArrayList<Integer> aPart = new ArrayList<Integer>();
	  ArrayList<Integer> bPart = new ArrayList<Integer>();
	  //System.out.println(" ");
	  for (IntWritable value : values) {
		  aPart.add(Integer.parseInt(value.toString()));
		  bPart.add(Integer.parseInt(value.toString()));
		  //System.out.print(value + " ");
	  }
	  //System.out.println(" ");
	  for (Integer a : aPart) {
		  for (Integer b : bPart) {
		  //System.out.print("a :"+ a + " b :" + b);
			  int c = a.compareTo(b);
			  if(c>0){
					String s = b + " "+ a;
					context.write(new Text(s), key);
			  }
//			  } else if (c < 0){
//					String s = a + " "+ b;
//					context.write(new Text(s), key);				  
//			  }
		  }
	  }
//		for (IntWritable value : values) {
//			System.out.print(value + " ");
//			if (prev.equals(" ")){
//
//			}else{
//				for(IntWritable a : aPart){
//					String s = a + " "+ value;
//					context.write(new Text(s), key);
//				}				
//				
//			}
//			prev = value.toString();
//			aPart.add(value);
//		}
//			System.out.println("marakhi: key "+ key);
//			System.out.println("marakhi: value "+ value);
//		for (IntWritable a : aPart) {
//			System.out.println("marakhi: key "+ key);
//			System.out.println("marakhi: value " + aPart);
//			for (IntWritable b : bPart) {
//				System.out.println("marakhi1: key "+ key);
//				System.out.println("marakhi1: value " + bPart);
//				int c = a.compareTo(b);
//				if(c > 0){
//					key1 =  b.toString() + " " + a;
//					context.write(new Text(key1), key);	
//				}
//				if(c < 0){
//					key1 =  a.toString() + " " + b;
//					context.write(new Text(key1), key);	
//				}
//			}
//		}	
		

  }
}
