import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.io.*;

public class CommonFollowersReducer1 extends
    Reducer<Text, IntWritable, Text, Text> {
	
	//Text textValue = new Text();
  public void reduce(Text key, Iterable<IntWritable> values, Context context)
      throws IOException, InterruptedException {
	  String s = "{";
	  for (IntWritable value : values) {
		  s = s + value + ",";		  
	  }
	  int a = s.length();
	  a = a -1;
	  String s1= s.substring(0, a);
	  s1 = s1 + "}";
	  context.write(key, new Text(s1));
  }
}
