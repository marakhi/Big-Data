import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;
import org.apache.hadoop.util.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;

public class CommonFollowersDriver extends Configured implements Tool {
  public static void main(String[] args) throws Exception {	  
    	int exitCode = ToolRunner.run(new Configuration(), new CommonFollowersDriver(),args);
    System.exit(exitCode);
  }

public int run(String[] args) throws Exception {
	if (args.length != 2) {
	      System.err.println("Usage: cooccurrences <input path> <output path>");
	      System.exit(-1);
	    }

//Initializing the map reduce job
	Job job= new Job(getConf());
	job.setJarByClass(CommonFollowersDriver.class);
	job.setJobName("CommonFollowersDriverstep1");
	//Setting the input and output paths.The output file should not already exist. 
	FileInputFormat.addInputPath(job, new Path(args[0]));
	Path tempout = new Path("temp");
	SequenceFileOutputFormat.setOutputPath(job, tempout);
	job.setOutputFormatClass(SequenceFileOutputFormat.class);
	//FileOutputFormat.setOutputPath(job, new Path(args[1]));	
	//Setting the mapper, reducer, and combiner classes
	job.setMapperClass(CommonFollowersMapper.class);
	job.setReducerClass(CommonFollowersReducer.class);
	//job.setCombinerClass(CommonFollowersReducer.class); 
	//Setting the output key value type of the mapper 
    job.setMapOutputKeyClass(IntWritable.class);
    job.setMapOutputValueClass(IntWritable.class);
	//Setting the format of the key-value pair to write in the output file.
	job.setOutputKeyClass(Text.class);
	job.setOutputValueClass(IntWritable.class);
	//Submit the job and wait for its completion
	job.waitForCompletion(true);
	
	Job job1= new Job(getConf());
	job1.setJarByClass(CommonFollowersDriver.class);
	job1.setJobName("CommonFollowersDriverstep2");
	//Setting the input and output paths.The output file should not already exist. 
	job1.setInputFormatClass(SequenceFileInputFormat.class);
	SequenceFileInputFormat.addInputPath(job1, tempout);
	FileOutputFormat.setOutputPath(job1, new Path(args[1]));
	//FileOutputFormat.setOutputPath(job, new Path(args[1]));	
	//Setting the mapper, reducer, and combiner classes
	//job.setMapperClass(CommonFollowersMapper.class);
	job1.setReducerClass(CommonFollowersReducer1.class);
	//job.setCombinerClass(CommonFollowersReducer.class); 
	//Setting the output key value type of the mapper 
    job1.setMapOutputKeyClass(Text.class);
    job1.setMapOutputValueClass(IntWritable.class);
	//Setting the format of the key-value pair to write in the output file.
	job1.setOutputKeyClass(Text.class);
	job1.setOutputValueClass(Text.class);
	//Submit the job and wait for its completion
	job1.waitForCompletion(true);
	return(job1.waitForCompletion(true) ? 0 : 1);
}
}
