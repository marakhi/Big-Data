import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.io.*;

public class CommonFollowersMapper extends
    Mapper<LongWritable, Text, IntWritable, IntWritable> {
	Text textKey = new Text();
	Text textValue = new Text();
	
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {

  	  String line = value.toString().trim();
      line = line.trim().replaceAll("\n", "");
      
      String[] result = line.split(" ");
      
      int mykey = Integer.parseInt(result[0].trim());
      // key for relation A [uniquecarrier, yy-mm-dd, origin]
      int myvalue = Integer.parseInt(result[1].trim());
      
      context.write(new IntWritable(mykey), new IntWritable(myvalue));
	 }
    }
 

